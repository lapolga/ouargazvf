# OUARGAZ APP V6.5 PRO

Livrable complet Web + Android.

## Lancement Web

```bash
cd OUARGAZ_APP_V6_5_PRO_WEB_ANDROID/ouargaz-app
npm install
npx prisma generate
npx prisma db push
npm run dev
```

## Génération APK Android

Pousser le dossier sur GitHub avec `.github` à la racine, puis :

GitHub → Actions → Build OUARGAZ Chef Equipe APK → Run workflow.

L'artifact généré contient : `OUARGAZ_CHEF_EQUIPE.apk`.
